import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

/**
 * Created by shiri.ron on 1/9/17.
 */
public class CompilationEngine {

    private static final String VAR_DEC_START = "<varDec>";
    private static final String VAR_DEC_END = "</varDec>";
    private static final String PARAMETER_START = "<parameterList>" ;
    private static final String PARAMETER_END = "</parameterList>";
    private static final String SUBROUTINE_BODY_START = "<subroutineBody>";
    private static final String SUBROUTINE_BODY_END = "</subroutineBody>";
    private static final String STATEMENTS_START =  "<statements>";
    private static final String STATEMENTS_END = "</statements>";
    private static final String DO_STATEMENT_START = "<doStatement>";
    private static final String DO_STATEMENT_END = "</doStatement>" ;
    private static final String EXPRESSION_LIST_START = "<expressionList>";
    private static final String EXPRESSION_LIST_END = "</expressionList>";
    private static final String EXPRESSION_START = "<expression>";
    private static final String EXPRESSION_END = "</expression>";
    private static final String TERM_START = "<term>";
    private static final String TERM_END = "</term>";
    private static final String LET_START = "<letStatement>";
    private static final String LET_END = "</letStatement>";
    private static final String RETURN_START = "<returnStatement>";
    private static final String RETURN_END = "</returnStatement>";
    private static final String IF_START = "<ifStatement>" ;
    private static final String IF_END = "</ifStatement>";
    private static final String WHILE_START = "<whileStatement>";
    private static final String WHILE_END =  "</whileStatement>";
    private static List <String> UNARY_OPS = Arrays.asList("~","-");
    private static List <String> BINARY_OPS = Arrays.asList("+","-","*","/","&","|","<",">","=");
    private static List<String> KEYWORD_CONSTANTS = Arrays.asList("true","false","null","this");
    private static String CLASS_START = "<class>";
    private static String CLASS_END = "</class>";
    private static String CLASS_VAR_DEC_START = "<classVarDec>";
    private static String CLASS_VAR_DEC_END = "</classVarDec>";
    private static String SUBROUTINE_DEC_START = "<subroutineDec>";
    private static String SUBROUTINE_DEC_END = "</subroutineDec>";
    private static String CLASS_TOKEN = "class";

    JackTokenizer tokenizer;
    BufferedWriter writer;


    CompilationEngine(File inputFile, String xmlFilename) throws Exception {
        this.tokenizer = new JackTokenizer(inputFile);
        this.writer =  new BufferedWriter(new FileWriter(xmlFilename));
    }



    public void compileClass() throws Exception {
        this.write(CLASS_START);
        this.write(this.tokenizer.parseToken(this.tokenizer.getNextToken())); //writes the word "class"
        this.write(this.tokenizer.parseToken(this.tokenizer.getNextToken())); //writes the classname
        this.write(this.tokenizer.parseToken(this.tokenizer.getNextToken())); //writes "{"
        String token = this.tokenizer.getNextToken();
        while (!token.equals("}"))
        {
            if (token.equals("field") || token.equals("static"))
            {
                compileClassVarDec(token);
            }
            else if (token.equals("method") || token.equals("function") || token.equals("constructor"))
            {
                compileSubroutineDec(token);

            }
            else
            {
                continue;
            }
            token = this.tokenizer.getNextToken();
        }
        this.write(this.tokenizer.parseToken(token));
        writer.write(CLASS_END);
    }

    private void compileSubroutineDec(String token) throws Exception {
        this.write(SUBROUTINE_DEC_START);
        this.write(this.tokenizer.parseToken(token)); //writes function/method/constructor
        this.write(this.tokenizer.parseToken(this.tokenizer.getNextToken())); //writes return type//void
        this.write(this.tokenizer.parseToken(this.tokenizer.getNextToken())); //writes name of subroutine
        token = this.tokenizer.getNextToken();
        this.write(this.tokenizer.parseToken(token)); //write out "("
        compileParameterList();
        this.write(SUBROUTINE_DEC_END);
    }

    private void compileParameterList() throws Exception {
        this.write(PARAMETER_START);
        String token = this.tokenizer.getNextToken();
        while (!token.equals(")"))
        {
            this.write(this.tokenizer.parseToken(token));
            token = this.tokenizer.getNextToken();
        }
        this.write(PARAMETER_END);
        this.write(this.tokenizer.parseToken(token));
        compileSubroutineBody();

    }

    private void compileSubroutineBody() throws Exception {
        String token = this.tokenizer.getNextToken();
        this.write(SUBROUTINE_BODY_START);
        this.write(this.tokenizer.parseToken(token)); //write "{"
        token = this.tokenizer.getNextToken();
        boolean emptyStatement = true;
        while (!token.equals("}"))
        {
            if (token.equals("var")) {
                this.compileVarDec(token);
                token = this.tokenizer.getNextToken();
            }
            else {
                token = compileStatements(token);
                emptyStatement = false;
            }
        }
        if (emptyStatement)
        {
            this.write(STATEMENTS_START);
            this.write(STATEMENTS_END);
        }
        this.write(this.tokenizer.parseToken(token)); //write "}"
        this.write(SUBROUTINE_BODY_END);
    }

    private String compileStatements(String token) throws Exception {
        //doesn't write "{" at the end or "}" at the start, but it returns "}"
        this.write(STATEMENTS_START);
        while (token.equals("do") || token.equals("let") || token.equals("return")
                || token.equals("if") || token.equals("while")) {
            if (token.equals("do")) {
                token = compileDoStatement(token);
            }
            else if (token.equals("let")) {
                token = compileLetStatement(token);
            }
            else if (token.equals("return")) {
                token = compileReturnStatement(token);
            }
            else if (token.equals("if")) {
                token = compileIfStatement(token);
            }
            else if (token.equals("while")) {
                token = compileWhileStatement(token);
            }
            else
            {
                continue;
            }
        }
        this.write(STATEMENTS_END);
        return token; //return "}"
    }

    private String compileDoStatement(String token) throws Exception {
        this.write(DO_STATEMENT_START);
        while (!token.equals("("))
        {
            this.write(this.tokenizer.parseToken(token));
            token = this.tokenizer.getNextToken();
        }
        this.write(this.tokenizer.parseToken(token));
        compileExpressionList();
        token = this.tokenizer.getNextToken();
        this.write(this.tokenizer.parseToken(token)); //write out ";"
        this.write(DO_STATEMENT_END);
        return this.tokenizer.getNextToken();
    }

    private void compileExpressionList() throws Exception {
        this.write(EXPRESSION_LIST_START);
        String token = this.tokenizer.getNextToken();
        while (!token.equals(")"))
        {
            if (token.equals(","))
            {
                this.write(this.tokenizer.parseToken(token));
                token = this.tokenizer.getNextToken();
            }
            else
            {
                token = compileExpression(token);
            }
        }
        this.write(EXPRESSION_LIST_END);
        this.write(this.tokenizer.parseToken(token));
    }

    private String compileExpression(String token) throws Exception {
        this.write(EXPRESSION_START);
        boolean firstInExpression = true;
        while (!token.equals(";") && !token.equals(")") && !token.equals("]") && !token.equals(","))
        {
            //handle one token terms
            if (UNARY_OPS.contains(token) && firstInExpression)
            {
                token = compileTerm(token);
                firstInExpression = false;
            }
            else if (token.equals("=") || token.equals(">") || token.equals("<"))
            {
                this.write(this.tokenizer.parseToken(token)); //write "="
                token = compileTerm (this.tokenizer.getNextToken());
            }
            else if (BINARY_OPS.contains(token)) {
                this.write(this.tokenizer.parseToken(token));
                token = this.tokenizer.getNextToken();
                firstInExpression = false;
            }
            else
            {
                token = compileTerm(token);
                firstInExpression = false;
            }

        }
        this.write(EXPRESSION_END);
        return token;
    }

    private String compileTerm (String token) throws Exception {
        this.write(TERM_START);
        String nextToken;
        String parsedToken = this.tokenizer.parseToken(token);
        //handle all one token terms
        if (parsedToken.startsWith(JackTokenizer.INTEGER_START) ||
                parsedToken.startsWith(JackTokenizer.STRING_CONSTANT_START) ||
                KEYWORD_CONSTANTS.contains(token))
        {
            this.write(parsedToken);
            nextToken = this.tokenizer.getNextToken();
        }
        else if (token.equals("("))
        {
            this.write(this.tokenizer.parseToken(token));
            token = compileExpression(this.tokenizer.getNextToken());
            this.write(this.tokenizer.parseToken(token)); //write out ")"
            nextToken = this.tokenizer.getNextToken();

        }
        else
        {
            if (UNARY_OPS.contains(token))
            {
                this.write(this.tokenizer.parseToken(token));
                nextToken = compileTerm(this.tokenizer.getNextToken());
            }
            else
            {
                nextToken = this.tokenizer.getNextToken();
                //handle subroutine call
                if (nextToken.equals(".") || nextToken.equals("("))
                {
                    this.write(this.tokenizer.parseToken(token));
                    token = nextToken;
                    while (!token.equals("("))
                    {
                        this.write(this.tokenizer.parseToken(token));
                        token = this.tokenizer.getNextToken();
                    }
                    this.write(this.tokenizer.parseToken("("));
                    compileExpressionList();
                    nextToken = this.tokenizer.getNextToken();
                }
                else {
                    if (nextToken.equals("[")) {
                        this.write(this.tokenizer.parseToken(token));
                        this.write(this.tokenizer.parseToken(nextToken));
                        this.write(this.tokenizer.parseToken(compileExpression(this.tokenizer.getNextToken())));
                        nextToken = this.tokenizer.getNextToken();
                    } else {
                        this.write(this.tokenizer.parseToken(token));
                    }
                }

            }

        }

        this.write(TERM_END);
        return nextToken;
    }

    private String compileLetStatement(String token) throws Exception {
        this.write(LET_START);
        while (!token.equals(";"))
        {
            this.write(this.tokenizer.parseToken(token));
            if (token.equals("[") || token.equals("="))
            {
                token = compileExpression(this.tokenizer.getNextToken());
            }
            else {
                token = this.tokenizer.getNextToken();
            }
        }
        this.write(this.tokenizer.parseToken(token));
        this.write(LET_END);
        return this.tokenizer.getNextToken();
    }



    private String compileReturnStatement(String token) throws Exception {
        this.write(RETURN_START);
        this.write(this.tokenizer.parseToken(token));
        token = this.tokenizer.getNextToken();
        if(!token.equals(";"))
        {
            token = compileExpression(token);
            this.write(this.tokenizer.parseToken(token)); //write out ";"

        }
        else
        {
            this.write(this.tokenizer.parseToken(token)); //write out ";"
        }
        this.write(RETURN_END);
        return this.tokenizer.getNextToken();
    }


    private String compileIfStatement(String token) throws Exception {
        this.write(IF_START);
        this.write(this.tokenizer.parseToken(token)); //write if word
        this.write(this.tokenizer.parseToken(this.tokenizer.getNextToken())); // write "("
        token = compileExpression(this.tokenizer.getNextToken()); // compiles expression
        this.write(this.tokenizer.parseToken(token)); //compiles ")"
        this.write(this.tokenizer.parseToken(this.tokenizer.getNextToken())); //writes "{"
        token = compileStatements(this.tokenizer.getNextToken());
        this.write(this.tokenizer.parseToken(token)); //writes "}"
        token = this.tokenizer.getNextToken();
        if (token.equals("else"))
        {
            this.write(this.tokenizer.parseToken(token)); //write else word
            this.write(this.tokenizer.parseToken(this.tokenizer.getNextToken())); //write {
            token = compileStatements(this.tokenizer.getNextToken()); //compile statements
            this.write(this.tokenizer.parseToken(token)); //writes "}"
            this.write(IF_END);
            return this.tokenizer.getNextToken();
        }
        this.write(IF_END);
        return token;
    }



    private String compileWhileStatement(String token) throws Exception {
        this.write(WHILE_START);
        this.write(this.tokenizer.parseToken(token)); //writes "while"
        this.write(this.tokenizer.parseToken(this.tokenizer.getNextToken())); // write "("
        token = compileExpression(this.tokenizer.getNextToken()); // compiles expression and returns ")"
        this.write(this.tokenizer.parseToken(token));
        this.write(this.tokenizer.parseToken(this.tokenizer.getNextToken())); //writes "{"
        token = compileStatements(this.tokenizer.getNextToken());
        this.write(this.tokenizer.parseToken(token)); //writes "}"
        String nextToken = this.tokenizer.getNextToken();
        this.write(WHILE_END);
        return nextToken;


    }


    private void compileVarDec(String token) throws Exception {
        this.write(VAR_DEC_START);
        while (!token.equals(";"))
        {
            this.write(this.tokenizer.parseToken(token));
            token = this.tokenizer.getNextToken(); //to - was here
        }
        this.write(this.tokenizer.parseToken(token));
        this.write(VAR_DEC_END);
    }

    private void compileClassVarDec(String token) throws Exception {
        this.write(CLASS_VAR_DEC_START);
        String parsedToken;
        while (!token.equals(";"))
        {
            parsedToken = this.tokenizer.parseToken(token);
            this.write(parsedToken);
            token = this.tokenizer.getNextToken();
        }
        this.write(this.tokenizer.parseToken(token));
        this.write(CLASS_VAR_DEC_END);
    }


    void close() throws Exception
    {
        this.tokenizer.close();
        this.writer.close();
    }

    void write (String content) throws IOException
    {
        this.writer.write(content);
        this.writer.newLine();

    }



}
