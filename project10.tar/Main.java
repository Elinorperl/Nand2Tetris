import java.io.File;
import java.util.ArrayList;

/**
 * Assembler - the main execution - opens given file and
 * creates a new hack file to return
 */
public class Main {
    /**
     * main function that creates a hack file to translate the given file
     *
     * @param args - the arguments given (a directory or single asm file)
     * @throws Exception throws an exception if there are parsing problems
     */
    public static void main(String[] args) throws Exception {
        File file = new File(args[0]);
        ArrayList <File>  jackFiles;
        if (file.isDirectory())
        {
            jackFiles = Main.getJackFile(file);
        }
        else
        {
            jackFiles = new ArrayList<>();
            jackFiles.add(file);
        }
        for (File jackFile : jackFiles) {
            String xmlFile;
            xmlFile = jackFile.getPath().replace(".jack", ".xml");
            CompilationEngine engine = new CompilationEngine(jackFile, xmlFile);
            engine.compileClass();
            engine.close();
        }
    }

    private static ArrayList<File> getJackFile(File directory) throws Exception {
        File [] files = directory.listFiles();
        ArrayList<File> jackFiles = new ArrayList<>();
        for (File file: files)
        {
            if (file.getName().endsWith(".jack"))
            {
                jackFiles.add(file);
            }
        }
        return jackFiles;

    }
}

