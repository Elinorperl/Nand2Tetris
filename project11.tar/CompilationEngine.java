import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Pattern;

public class CompilationEngine {
    private enum subroutineType { FUNCTION, METHOD, CONSTRUCTOR}
    private static List <String> UNARY_OPS = Arrays.asList("~","-");
    private static List <String> BINARY_OPS = Arrays.asList("+","-","*","/","&","|","<",">","=");
    private static List<String> KEYWORD_CONSTANTS = Arrays.asList("true","false","null","this");
    private static String IDENTIFIER_REGEX = "[\\w_]+";

    private JackTokenizer tokenizer;
    private VMWriter vmWriter;
    private SymbolTable symbolTable;
    private String className;
    private String subroutineName;
    private int whileLabelIndex;
    private int ifLabelIndex;
    private int fieldsCounter;
    private subroutineType subType;
    private String subroutineReturnType;
    private static String INT_REGEX = "[0-9]+";
    private static String STRING_REGEX = "\"\"";


    CompilationEngine(File inputFile, File outputFile) throws Exception {
        this.tokenizer = new JackTokenizer(inputFile);
        this.vmWriter = new VMWriter(outputFile);
        this.symbolTable = new SymbolTable();
        this.whileLabelIndex = 0;
        this.fieldsCounter = 0;
        this.ifLabelIndex = 1;

    }

    public void compileClass() throws Exception {
        this.tokenizer.getNextToken(); //iterates over the word "class"
        className = this.tokenizer.getNextToken(); //writes className
        this.tokenizer.getNextToken(); //iterates over "{"
        String token = this.tokenizer.getNextToken();
        while (!token.equals("}"))
        {
            if (token.equals("field") || token.equals("static"))
            {
                compileClassVarDec(token);
            }
            else if (token.equals("method") || token.equals("function") || token.equals("constructor"))
            {
                determineSubroutineType(token);
                compileSubroutineDec(token);

            }
            else
            {
                continue;
            }
            token = this.tokenizer.getNextToken();
        }
        vmWriter.close();
        tokenizer.close();
    }

    private void determineSubroutineType(String token) throws Exception {
        switch (token)
        {
            case "method": this.subType = subroutineType.METHOD;
                break;
            case "constructor": this.subType = subroutineType.CONSTRUCTOR;
                break;
            case "function": this.subType = subroutineType.FUNCTION;
                break;
            default: this.subType = subroutineType.FUNCTION;
        }

    }

    private void compileClassVarDec(String token) throws Exception {
        KIND kind;
        if (token.equals("static"))
        {
            kind = KIND.STATIC;
        }
        else
        {
            kind = KIND.FIELD;
        }
        String type = this.tokenizer.getNextToken();
        ArrayList<String> variableNames = new ArrayList<>();
        //iterate over variables
        while (!token.equals(";"))
        {
            variableNames.add(this.tokenizer.getNextToken()); //add new variable to variable names list
            if (kind.equals(KIND.FIELD))
            {
                this.fieldsCounter++;
            }
            token = this.tokenizer.getNextToken(); //check next symbol to see if it's ; or ,

        }

        //push variables to appropriate segment and add to symbol table
        for (String varName: variableNames)
        {
            this.symbolTable.define(varName,type,kind);
        }
    }

    private void compileSubroutineDec(String token) throws Exception {
        this.symbolTable.startSubroutine();
        this.subroutineReturnType = this.tokenizer.getNextToken(); //token is return type//void
        this.subroutineName = this.className +"." + this.tokenizer.getNextToken(); // token is the name of the subroutine
        this.whileLabelIndex = 0;
        this.ifLabelIndex = 0;
        token = this.tokenizer.getNextToken(); // token is "(";\
        compileParameterList();

    }

    private void compileSubroutineBody() throws Exception {
        String token = this.tokenizer.getNextToken(); // get "{"
        token = this.tokenizer.getNextToken(); //get variable decleration or statement
        while (!token.equals("}"))
        {
            if (token.equals("var"))
            {
                token = this.compileVarDec(token);
            }
            else
            {
                int nVars = symbolTable.kindCounter.get(KIND.VAR);
                vmWriter.writeFunction(this.subroutineName,nVars);
                if (this.subType.equals(subroutineType.CONSTRUCTOR))
                {
                    this.vmWriter.writePush(VMWriter.SEGMENT.CONST,this.fieldsCounter); // push to stack number of fields
                    this.vmWriter.writeCall("Memory.alloc",1);
                    this.vmWriter.writePop(VMWriter.SEGMENT.POINTER,0);
                }
                else if (this.subType.equals(subroutineType.METHOD)) {
                    this.vmWriter.writePush(VMWriter.SEGMENT.ARG, 0);
                    this.vmWriter.writePop(VMWriter.SEGMENT.POINTER, 0);
                }
                token = compileStatements(token);
            }

        }
    }



    private void compileParameterList() throws Exception {
        String token = this.tokenizer.getNextToken();
        String argName;
        String argType;
        boolean firstParameter = true;
        if (this.subType.equals(subroutineType.METHOD))
        {
            this.symbolTable.define("this",this.className ,KIND.ARG);
        }
        while (!token.equals(")"))
        {
            if (firstParameter)
            {
                argType = token;
                firstParameter = false;
            }
            else
            {
                argType = this.tokenizer.getNextToken();
            }
            argName = this.tokenizer.getNextToken();
            this.symbolTable.define(argName,argType,KIND.ARG);
            token = this.tokenizer.getNextToken();
        }
        compileSubroutineBody();

    }


    private String compileVarDec(String token) throws Exception {
        token = this.tokenizer.getNextToken();
        String varType = token;
        token = this.tokenizer.getNextToken();
        while (!token.equals(";"))
        {
            if(Pattern.matches(IDENTIFIER_REGEX,token))
            {
                symbolTable.define(token, varType, KIND.VAR);
            }
            token = this.tokenizer.getNextToken();
        }
        return this.tokenizer.getNextToken();
    }

    private String compileStatements(String token) throws Exception {
        //doesn't write "{" at the end or "}" at the start, but it returns "}"
        while (token.equals("do") || token.equals("let") || token.equals("return")
                || token.equals("if") || token.equals("while")) {
            if (token.equals("do")) {
                token = compileDoStatement(token);
            }
            else if (token.equals("let")) {
                token = compileLetStatement(token);
            }
            else if (token.equals("return")) {
                token = compileReturnStatement(token);
            }
            else if (token.equals("if")) {
                token = compileIfStatement(token);
            }
            else if (token.equals("while")) {
                token = compileWhileStatement(token);
            }
            else
            {
                continue;
            }
        }
        return token; //returns the end of the above statements
    }

    private String compileDoStatement(String token) throws Exception {
        token = this.tokenizer.getNextToken();
        String subName = token;
        token = this.tokenizer.getNextToken();
        if (token.equals("(")) {
            vmWriter.writePush(VMWriter.SEGMENT.POINTER, 0);
            int nArgs= compileExpressionList();
            vmWriter.writeCall(this.className + "." + subName, nArgs +1);
        }
        else if (token.equals("."))
        {
            String objectName = subName;
            token = this.tokenizer.getNextToken();
            subName = token;
            String type = symbolTable.typeOf(objectName);
            if (type.equals(""))
            {
                this.subroutineName = objectName + "." + subName;
                this.tokenizer.getNextToken();
                int nArgs = compileExpressionList();
                vmWriter.writeCall(this.subroutineName, nArgs);
            }
            else
            {
                vmWriter.writePush(getSegment(symbolTable.kindOf(objectName)), symbolTable.indexOf(objectName));
                this.subroutineName = symbolTable.typeOf(objectName) + "." +subName;
                this.tokenizer.getNextToken();
                int nArgs = compileExpressionList();
                vmWriter.writeCall(this.subroutineName, nArgs+1);
            }

        }
        vmWriter.writePop(VMWriter.SEGMENT.TEMP,0);
        token = this.tokenizer.getNextToken(); //get past ;
        return this.tokenizer.getNextToken();
    }


    private String compileLetStatement(String token) throws Exception {
        token = this.tokenizer.getNextToken();
        boolean isArray = false;
        String assignedValue = token;
        token = this.tokenizer.getNextToken();
        if(token.equals("["))
        {
            isArray = true;
            pushVar(assignedValue);
            token = this.tokenizer.getNextToken(); // move past "="
        }
        token = compileExpression(this.tokenizer.getNextToken());
        if (isArray)
        {
            vmWriter.writePop(VMWriter.SEGMENT.TEMP,0);
            vmWriter.writePop(VMWriter.SEGMENT.POINTER,1);
            vmWriter.writePush(VMWriter.SEGMENT.TEMP, 0);
            vmWriter.writePop(VMWriter.SEGMENT.THAT, 0);
        }
        else
        {
            popVar(assignedValue);
        }
        return this.tokenizer.getNextToken();
    }

    private void pushVar(String varName) throws Exception
    {
        compileExpression(this.tokenizer.getNextToken());
        if (symbolTable.kindOf(varName).equals(KIND.ARG))
        {
            vmWriter.writePush(VMWriter.SEGMENT.ARG,symbolTable.indexOf(varName));
        }
        else if (symbolTable.kindOf(varName).equals(KIND.VAR))
        {
            vmWriter.writePush(VMWriter.SEGMENT.LOCAL,symbolTable.indexOf(varName));
        }
        else if (symbolTable.kindOf(varName).equals(KIND.STATIC))
        {
            vmWriter.writePush(VMWriter.SEGMENT.STATIC,symbolTable.indexOf(varName));
        }
        else
        {
            vmWriter.writePush(VMWriter.SEGMENT.THIS, symbolTable.indexOf(varName));
        }
        vmWriter.writeArithmetic(VMWriter.COMMAND.ADD);
    }

    private void popVar (String varName) throws Exception
    {
        if (symbolTable.kindOf(varName).equals(KIND.ARG))
        {
            vmWriter.writePop(VMWriter.SEGMENT.ARG,symbolTable.indexOf(varName));
        }
        else if (symbolTable.kindOf(varName).equals(KIND.VAR))
        {
            vmWriter.writePop(VMWriter.SEGMENT.LOCAL,symbolTable.indexOf(varName));
        }
        else if (symbolTable.kindOf(varName).equals(KIND.STATIC))
        {
            vmWriter.writePop(VMWriter.SEGMENT.STATIC,symbolTable.indexOf(varName));
        }
        else
        {
            vmWriter.writePop(VMWriter.SEGMENT.THIS, symbolTable.indexOf(varName));
        }
    }

    private String compileWhileStatement(String token) throws Exception {
        int curIndex = this.whileLabelIndex;
        this.whileLabelIndex ++ ;
        vmWriter.writeLabel("WHILE_EXP"+curIndex);
        token = this.tokenizer.getNextToken(); // advances to "("
        token = compileExpression(this.tokenizer.getNextToken()); // compiles expression and returns ")"
        vmWriter.writeArithmetic(VMWriter.COMMAND.NOT); // if the negation of the condition happens , go to end of loop
        vmWriter.writeIfGoTo("WHILE_END" + curIndex);
        token = this.tokenizer.getNextToken(); //writes "{"
        token = compileStatements(this.tokenizer.getNextToken()); // is on token "}"
        vmWriter.writeGoTo("WHILE_EXP"+curIndex);
        vmWriter.writeLabel("WHILE_END"+curIndex);
        return this.tokenizer.getNextToken();
    }

    private String compileReturnStatement(String token) throws Exception {
        token = this.tokenizer.getNextToken();
        if(!token.equals(";"))
        {
            token = compileExpression(token);
        }
        else
        {
            vmWriter.writePush(VMWriter.SEGMENT.CONST, 0);
        }
        vmWriter.writeReturn();
        return this.tokenizer.getNextToken();
    }

    private String compileIfStatement(String token) throws Exception {
        int curLabelIndex = this.ifLabelIndex;
        this.ifLabelIndex ++;
        token = this.tokenizer.getNextToken(); //iterates to "("
        token = compileExpression(this.tokenizer.getNextToken()); // compiles expression and token is ")"
        token = this.tokenizer.getNextToken(); //compiles "{"
        vmWriter.writeIfGoTo("IF_TRUE"+curLabelIndex);
        vmWriter.writeGoTo("IF_FALSE"+curLabelIndex);
        vmWriter.writeLabel("IF_TRUE"+curLabelIndex);
        token = compileStatements(this.tokenizer.getNextToken()); //ends at "}"
        token = this.tokenizer.getNextToken();
        if (token.equals("else"))
        {
            vmWriter.writeGoTo("IF_END"+curLabelIndex);
            vmWriter.writeLabel("IF_FALSE"+curLabelIndex);
            this.tokenizer.getNextToken(); //iterates over {
            compileStatements(this.tokenizer.getNextToken()); //compile statements which ends }
            vmWriter.writeLabel("IF_END"+curLabelIndex);
            return this.tokenizer.getNextToken();
        }
        else
        {
            vmWriter.writeLabel("IF_FALSE"+curLabelIndex);
        }
        return token;
    }

    private String compileExpression(String token) throws Exception {
        String op;
        if (UNARY_OPS.contains(token))
        {
            op = token;
            token = compileTerm(this.tokenizer.getNextToken());
            writeUnaryOp(op);
        }
        while (!token.equals(";") && !token.equals(")") && !token.equals("]") && !token.equals(","))
        {
            //handle one token terms
            if (BINARY_OPS.contains(token))
            {
                op = token;
                token = compileTerm (this.tokenizer.getNextToken());
                writeBinaryOp(op);
            }
            else
            {
                token = compileTerm(token);
            }
        }
        return token;
    }



    private String compileTerm (String token) throws Exception {
        String nextToken;
        String objectName;
        String calledFunctionName;
        String parsedToken = this.tokenizer.parseToken(token);
        //handle all one token terms
        if (parsedToken.startsWith(JackTokenizer.INTEGER_START)) {
            vmWriter.writePush(VMWriter.SEGMENT.CONST, Integer.parseInt(token));
            nextToken = this.tokenizer.getNextToken();

        }
        else if (parsedToken.startsWith(JackTokenizer.STRING_CONSTANT_START)) {
            createNewString(parsedToken);
            nextToken = this.tokenizer.getNextToken();
        }
        else if (KEYWORD_CONSTANTS.contains(token)) {
            parseKeywordConstant(token);
            nextToken = this.tokenizer.getNextToken();
        }
        else if (token.equals("(")) {
            token = compileExpression(this.tokenizer.getNextToken());
            nextToken = this.tokenizer.getNextToken();

        }
        else if (UNARY_OPS.contains(token)) {
            nextToken = compileTerm(this.tokenizer.getNextToken());
            writeUnaryOp(token);
        }
        else if (BINARY_OPS.contains(token)) {
            String binaryOp = token;
            nextToken = compileTerm(this.tokenizer.getNextToken());
            writeBinaryOp(token);
        }
        else
        {
            nextToken = this.tokenizer.getNextToken();
            //handle subroutine call
            if (nextToken.equals(".")) {

                objectName = token;
                String subName = this.tokenizer.getNextToken();
                int nArgs = 0;
                String type = this.symbolTable.typeOf(objectName);
                if (type.equals(""))
                {
                    subName = objectName + "." + subName;
                    this.tokenizer.getNextToken(); //get ( token
                    nArgs =   compileExpressionList();
                    nextToken = this.tokenizer.getNextToken();
                    vmWriter.writeCall(subName, nArgs);

                }
                else
                {
                    this.vmWriter.writePush(getSegment(symbolTable.kindOf(objectName)), symbolTable.indexOf(objectName));
                    subName = symbolTable.typeOf(objectName) + "." +subName;
                    this.tokenizer.getNextToken(); //get ( token
                    nArgs = compileExpressionList();
                    nextToken = this.tokenizer.getNextToken();
                    vmWriter.writeCall(subName, nArgs+1);
                }

            }
            else if (nextToken.equals("[")) {
                    String endToken = compileExpression(this.tokenizer.getNextToken()); //current expression is currently on top of stack
                    vmWriter.writePush(getSegment(symbolTable.kindOf(token)), symbolTable.indexOf(token));
                    vmWriter.writeArithmetic(VMWriter.COMMAND.ADD);
                    vmWriter.writePop(VMWriter.SEGMENT.POINTER, 1);
                    vmWriter.writePush(VMWriter.SEGMENT.THAT, 0);
                    nextToken = this.tokenizer.getNextToken();
                }
            else if (nextToken.equals("("))
            {
                String subName = token;
                this.vmWriter.writePush(VMWriter.SEGMENT.POINTER, 0);
                subName = this.className + "." +subName;
                int nArgs =  compileExpressionList();
                nextToken = this.tokenizer.getNextToken();
                vmWriter.writeCall(subName, nArgs+1);
            }
            else
            {
                KIND kind = symbolTable.kindOf(token);
                int index = symbolTable.indexOf(token);
                vmWriter.writePush(this.getSegment(kind),index);
            }
        }
        return nextToken;
    }

    private void writeBinaryOp(String token) throws Exception {
        switch (token) {
            case "+":
                vmWriter.writeArithmetic(VMWriter.COMMAND.ADD);
                break;
            case "-":
                vmWriter.writeArithmetic(VMWriter.COMMAND.SUB);
                break;
            case "&":
                vmWriter.writeArithmetic(VMWriter.COMMAND.AND);
                break;
            case "|":
                vmWriter.writeArithmetic(VMWriter.COMMAND.OR);
                break;
            case "<":
                vmWriter.writeArithmetic(VMWriter.COMMAND.LT);
                break;
            case ">":
                vmWriter.writeArithmetic(VMWriter.COMMAND.GT);
                break;
            case "=":
                vmWriter.writeArithmetic(VMWriter.COMMAND.EQ);
                break;
            case "*":
                vmWriter.writeArithmetic(VMWriter.COMMAND.MULT);
                break;
            case "/":
                vmWriter.writeArithmetic(VMWriter.COMMAND.DIVIDE);
                break;
            default:
        }
    }



    private void writeUnaryOp(String token) throws Exception {

        switch (token)
        {
            case "-":
                vmWriter.writeArithmetic(VMWriter.COMMAND.NEG);
                break;
            case "~":
                vmWriter.writeArithmetic(VMWriter.COMMAND.NOT);
                break;
        }

    }

    private void parseKeywordConstant(String token) throws Exception {
        switch (token)
        {
            case "true":
                vmWriter.writePush(VMWriter.SEGMENT.CONST,0);
                vmWriter.writeArithmetic(VMWriter.COMMAND.NOT);
                break;
            case "false":
                vmWriter.writePush(VMWriter.SEGMENT.CONST,0);
                break;
            case "null":
                vmWriter.writePush(VMWriter.SEGMENT.CONST, 0);
                break;
            case "this":
                vmWriter.writePush(VMWriter.SEGMENT.POINTER, 0);
                break;
            default:
        }
    }


    private void createNewString(String parsedToken) throws Exception  {
        String stringTerm = parsedToken.replace(JackTokenizer.STRING_CONSTANT_START,"").
                replace(JackTokenizer.STRING_CONSTANT_END,"");

        vmWriter.writePush(VMWriter.SEGMENT.CONST,stringTerm.length());
        vmWriter.writeCall("String.new", 1);
        for(int i = 0; i < stringTerm.length(); i++)
        {
            vmWriter.writePush(VMWriter.SEGMENT.CONST,(int)stringTerm.charAt(i));
            vmWriter.writeCall("String.appendChar", 2);
        }
    }


    //returns number of arguements - without incrementing for methods/constructor
    private int compileExpressionList() throws Exception {
        int nArgs = 0;
        String token = this.tokenizer.getNextToken();
        while (!token.equals(")"))
        {
            if (token.equals(","))
            {
                token = this.tokenizer.getNextToken();
            }
            else
            {
                token = compileExpression(token);
                nArgs ++;
            }
        }
        return nArgs;
    }

    private VMWriter.SEGMENT getSegment(KIND kind)
    {
        switch (kind)
        {
            case ARG:
                return VMWriter.SEGMENT.ARG;
            case FIELD:
                return VMWriter.SEGMENT.THIS;
            case STATIC:
                return VMWriter.SEGMENT.STATIC;
            case VAR:
                return VMWriter.SEGMENT.LOCAL;
            default: return null;
        }
    }



}



