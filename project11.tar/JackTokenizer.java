import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class JackTokenizer {

    static final String END_OF_FILE = "***EOF***" ;
    private static String DELIMETERS = "(){}[].,;+-*/&|<>=~";
    static String STRING_CONSTANT_START = "<stringConstant>";
    static String STRING_CONSTANT_END = "</stringConstant>";
    private static String SYMBOL_START = "<symbol>";
    private static String SYMBOL_END = "</symbol>";
    private static String KEYWORD_START = "<keyword>";
    private static String KEYWORD_END = "</keyword>";
    static String INTEGER_START = "<integerConstant>";
    private static String INTEGER_END = "</integerConstant>";
    private static String IDENTIFIER_START = "<identifier>";
    private static String IDENTIFIER_END = "</identifier>";

    private static String LT = "&lt;";
    private static String GT = "&gt;";
    private static String AMP = "&amp;";
    private static String SINGLE_QUOTE = "&quot;";
    private static String INT_REGEX = "[0-9]+";
    private static String STRING_REGEX = "\"[^\"\n]*\"";
    private static String IDENTIFIER_REGEX = "[\\w_]+";
    public static List <String> KEYWORDS = Arrays.asList("class", "static", "field", "int", "char", "boolean",
            "constructor", "function", "method", "void", "var", "let", "if", "else", "while", "do", "return", "true",
            "false", "null", "this");

    public void close() throws Exception {
        this.br.close();
    }


    private BufferedReader br;
    private StringTokenizer partTokenizer;
    private ArrayList<String> lineStringConstants;
    private LinkedList<String> lineParts;
    private boolean isPartOfComment;

    JackTokenizer(File file) throws Exception {
        this.br = new BufferedReader(new FileReader(file));
        this.partTokenizer = null;
        this.lineParts = null;
        this.lineStringConstants = new ArrayList <>();
        this.isPartOfComment = false;
    }

    String getNextToken() throws Exception
    {
        String token;
        String nextLine = null;
        if (this.partTokenizer == null) {
            if ((nextLine = this.br.readLine())!= null) {
                manageNewLine(nextLine);
            }
            else {
                return END_OF_FILE;
            }
        }
        while (this.partTokenizer.hasMoreTokens() || !this.lineParts.isEmpty() || (nextLine = this.br.readLine())!= null)
        {
            if (this.partTokenizer.hasMoreTokens())
            {
                token = this.partTokenizer.nextToken();
                if (!token.equals(""))
                    return token;
            }
            else if (!this.lineParts.isEmpty())
            {
                this.partTokenizer = new StringTokenizer(this.lineParts.remove(0),DELIMETERS,true);
            }
            else
            {
                manageNewLine(nextLine);
            }
        }
        return END_OF_FILE;
    }


    void manageNewLine (String line)
    {
        line = parseOutCommentsStrings(line).trim();
        this.lineParts = new LinkedList<>(Arrays.asList(line.split("\\s+")));
        this.partTokenizer = new StringTokenizer(this.lineParts.remove(0),DELIMETERS,true);

    }

    private String parseOutCommentsStrings (String line)
    {
        ArrayList <String > lineParts = new ArrayList<>();
        if (this.isPartOfComment)
        {
            if (!line.contains("*/"))
            {
                return "";
            }
            else
            {
                this.isPartOfComment = false;
                if (line.indexOf("*/") == line.length()-2)
                {
                    line = "";
                }
                else {
                    line =  line.substring(line.lastIndexOf("*/") + 2, line.length());
                }
            }
        }
        Pattern pattern = Pattern.compile("\"|/\\*|//"); //pattern of comment or string
        Matcher matcher = pattern.matcher(line);
        while (matcher.find())
        {
            int startIndexSpecial =matcher.start();
            //handle comment
            if (line.charAt(startIndexSpecial) == '/')
            {
                line = parseOutComment(line,startIndexSpecial);
                matcher = pattern.matcher(line);
            }
            //handle string
            else
            {
                Pattern pattern2 = Pattern.compile("[^\\\\]\"");
                Matcher matcher2 = pattern2.matcher(line.substring(startIndexSpecial));
                matcher2.find();
                String stringConstant = line.substring(startIndexSpecial+1,startIndexSpecial+matcher2.end()-1);
                this.lineStringConstants.add(stringConstant);
                String before =  line.substring(0,startIndexSpecial+1);
                String after = line.substring(startIndexSpecial+matcher2.end()-1,startIndexSpecial+matcher2.end());
                lineParts.add(before+after);
                line =  line.substring(startIndexSpecial+matcher2.end());
                matcher = pattern.matcher(line);
            }
        }
        while (!lineParts.isEmpty())
        {
            line = lineParts.remove(lineParts.size()-1) + line;
        }
        return line;
    }

    private String parseOutComment (String line, int startIndex)
    {
        char nextChar = line.charAt(startIndex+1);
        if (nextChar == '/')
        {
            return line.substring(0,startIndex);
        }
        int indexEndComment = line.indexOf("*/",startIndex);
        if (indexEndComment == -1)
        {
            this.isPartOfComment = true;
            if (line.contains("*/"))
            {
                this.isPartOfComment = false;
                return line.substring(0,line.indexOf("*/")) + line.substring(line.lastIndexOf("*/")+1);
            }
            else
            {
                return line.substring(0,startIndex);
            }
        }
        return line.substring(0,startIndex) + line.substring(indexEndComment+2);
    }


    String parseToken(String token) {
        if (token.isEmpty()) {
            return "";
        }
        if (token.equals(END_OF_FILE))
        {
            return END_OF_FILE;
        }
        if (token.equals("\"\""))
        {
            token = this.lineStringConstants.remove(0);
            return STRING_CONSTANT_START + token + STRING_CONSTANT_END;
        }
        if (token.equals("<"))
        {
            return SYMBOL_START + LT + SYMBOL_END;
        }
        if (token.equals(">"))
        {
            return SYMBOL_START + GT + SYMBOL_END;
        }
        if (token.equals("&"))
        {
            return SYMBOL_START + AMP + SYMBOL_END;
        }
        if (DELIMETERS.contains(token))
        {
            return SYMBOL_START + token + SYMBOL_END;
        }
        if (KEYWORDS.contains(token))
        {
            return KEYWORD_START + token + KEYWORD_END;
        }
        //identifiers can't start with a digit
        if (Character.isDigit(token.charAt(0)))
        {
            return INTEGER_START + token + INTEGER_END;
        }
        return IDENTIFIER_START + token + IDENTIFIER_END;
    }
}


