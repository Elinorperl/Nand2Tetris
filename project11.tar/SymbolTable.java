import java.util.HashMap;

enum KIND {STATIC, FIELD, ARG, VAR, NONE}

class SymbolTable
{
    private class symbolInfo
    {
        String type;
        KIND kind;
        int index;

        symbolInfo(String type, KIND kind, int index)
        {
            this.type = type;
            this.kind = kind;
            this.index = index;
        }
    }

    HashMap<KIND,Integer> kindCounter = new HashMap<>();
    private HashMap<String, symbolInfo> classTable;
    private HashMap<String, symbolInfo> subroutineTable;

    SymbolTable()
    {
        classTable = new HashMap<>();
        subroutineTable = new HashMap<>();
        initializeKindCounter();
    }

    private void initializeKindCounter()
    {
        kindCounter.put(KIND.STATIC,0);
        kindCounter.put(KIND.FIELD, 0);
        kindCounter.put(KIND.ARG, 0);
        kindCounter.put(KIND.VAR, 0);
    }

    void startSubroutine()
    {
        subroutineTable = new HashMap<>();
        kindCounter.put(KIND.ARG, 0);
        kindCounter.put(KIND.VAR, 0);
    }

    void define(String name, String type, KIND kind)
    {
        int index;
        symbolInfo info;
        switch (kind)
        {
            case ARG:
                index = kindCounter.get(KIND.ARG);
                info = new symbolInfo(type, kind, index);
                kindCounter.put(KIND.ARG,index+1);
                subroutineTable.put(name, info);
                break;
            case VAR:
                index = kindCounter.get(KIND.VAR);
                info = new symbolInfo(type, kind, index);
                kindCounter.put(KIND.VAR,index+1);
                subroutineTable.put(name, info);
                break;
            case FIELD:
                index = kindCounter.get(KIND.FIELD);
                info = new symbolInfo(type, kind, index);
                kindCounter.put(KIND.FIELD,index+1);
                classTable.put(name, info);
                break;
            case STATIC:
                index = kindCounter.get(KIND.STATIC);
                info = new symbolInfo(type, kind, index);
                kindCounter.put(KIND.STATIC,index+1);
                classTable.put(name, info);
                break;
        }
    }

    private symbolInfo checkInfo (String name)
    {
        if (classTable.get(name) != null)
        {
            return classTable.get(name);
        }
        else if (subroutineTable.get(name) != null)
        {
            return subroutineTable.get(name);
        }
        else
        {
            return null;
        }
    }

    int varCount (KIND kind)
    {
        return kindCounter.get(kind);
    }

    KIND kindOf (String name)
    {
        symbolInfo info = checkInfo(name);
        if (info != null)
        {
            return info.kind;
        }
        return KIND.NONE;
    }

    String typeOf(String name)
    {
        symbolInfo info = checkInfo(name);
        if (info != null)
        {
            return info.type;
        }
        return "";
    }

    int indexOf(String name)
    {
       symbolInfo info = checkInfo(name);
       if (info != null)
       {
           return info.index;
       }
       return -1;
    }

}
