import java.io.*;

public class VMWriter
{
    enum SEGMENT {CONST, ARG, LOCAL, STATIC, THIS, THAT, POINTER, TEMP}
    enum COMMAND {ADD, SUB, NEG, EQ, GT, LT, AND, OR, NOT, MULT, DIVIDE}

    private BufferedWriter writer;

    VMWriter(File output) throws Exception
    {
        this.writer =  new BufferedWriter(new FileWriter(output));
    }

    private String segmentString (SEGMENT segment)
    {
        switch (segment)
        {
            case CONST:
                return "constant";
            case ARG:
                return "argument";
            case LOCAL:
                return "local";
            case STATIC:
                return "static";
            case THIS:
                return "this";
            case THAT:
                return "that";
            case POINTER:
                return "pointer";
            case TEMP:
                return "temp";
            default:
                return "";
        }
    }

    private String commandString (COMMAND command)
    {
        switch (command)
        {
            case ADD:
                return "add";
            case AND:
                return "and";
            case EQ:
                return "eq";
            case GT:
                return "gt";
            case LT:
                return "lt";
            case NEG:
                return "neg";
            case NOT:
                return "not";
            case OR:
                return "or";
            case SUB:
                return "sub";
            case DIVIDE:
                return "call Math.divide 2";
            case MULT:
                return "call Math.multiply 2";
        }
        return "";
    }

    void writePush(SEGMENT SEGMENT, int index) throws Exception
    {
        writer.write("push " + segmentString(SEGMENT) + " " + Integer.toString(index) + "\n");
    }

    void writePop(SEGMENT SEGMENT, int index) throws Exception
    {
        writer.write("pop " + segmentString(SEGMENT) + " " + Integer.toString(index)+ "\n");
    }

    void writeArithmetic (COMMAND command) throws Exception
    {
        writer.write(commandString(command)+ "\n");
    }

    void writeLabel(String label) throws Exception
    {
        writer.write("label " + label+ "\n");
    }

    void writeGoTo (String label) throws Exception
    {
        writer.write( "goto " + label+ "\n");
    }

    void writeIfGoTo (String label) throws Exception
    {
        writer.write( "if-goto " + label+ "\n");
    }

    void writeCall (String name, int arguments) throws Exception
    {
        writer.write("call " + name + " " + Integer.toString(arguments)+ "\n");
    }

    void writeFunction (String name, int nLocals) throws Exception
    {
        writer.write("function " + name + " " + Integer.toString(nLocals)+ "\n");
    }

    void writeReturn() throws Exception
    {
        writer.write("return\n");
    }

    void close() throws IOException {
        writer.close();
    }

}
